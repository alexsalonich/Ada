export interface Question {
  rating: number;
  q: string;
  a: string[];
  correct: number;
  why: string;
  _used?: boolean;
}

export interface SubjectType {
  title: string;
  topics: Array<{
    id: string;
    name: string;
  }>;
}

export interface Subjects {
  [key: string]: SubjectType;
}

export interface QuestionBank {
  [key: string]: Question[];
}

export interface EloMap {
  [key: string]: number;
}

// function types used by the quiz logic
export type ExpectedFn = (player: number, opp: number) => number;
export type UpdateEloFn = (
  player: number,
  qRating: number,
  correct: boolean,
  K?: number,
  min?: number
) => number;
export type UpdateLearnEloFn = (
  player: number,
  qRating: number,
  correct: boolean,
  min?: number
) => number;
export type PickQuestionFn = (
  bank: Question[],
  playerElo: number,
  target?: number,
  step?: number,
  max?: number
) => Question | null;