import React, { useState, useEffect } from 'react';
import { Home, Book, Play, User, Trophy, Clock, Target, TrendingUp } from 'lucide-react';
import type {
  Question,
  SubjectType as Subject,
  Subjects,
  QuestionBank,
  EloMap,
  ExpectedFn,
  UpdateEloFn,
  UpdateLearnEloFn,
  PickQuestionFn
} from './types';

const SUBJECTS: Subjects = {
  math: {
    title: "Math",
    topics: [
      { id: "trig", name: "Trigonometry" },
      { id: "precalc", name: "Pre-Calculus" },
      { id: "calc1", name: "Calculus I" },
      { id: "linalg", name: "Linear Algebra" }
    ]
  },
  coding: {
    title: "Coding",
    topics: [
      { id: "code_puzzles", name: "Coding Puzzles" },
      { id: "debug", name: "Debug Quizzes" },
      { id: "mini_hack", name: "Mini-Hackathons" }
    ]
  },
  physics: {
    title: "Physics",
    topics: [
      { id: "phys_alg", name: "Algebra-Based" },
      { id: "phys_calc", name: "Calculus-Based" }
    ]
  },
  chem: {
    title: "Chemistry",
    topics: [
      { id: "chem1", name: "Chemistry I" },
      { id: "chem2", name: "Chemistry II" }
    ]
  }
};

const QUESTION_BANK: QuestionBank = {
  trig: [
    {"rating":500,"q":"sin(0) = ?","a":["0","1","−1","√2/2"],"correct":0, "why":"sin(0)=0 by unit circle."},
    {"rating":520,"q":"cos(0) = ?","a":["0","1","−1","√3/2"],"correct":1, "why":"cos(0)=1 at angle 0."},
    {"rating":540,"q":"tan(0) = ?","a":["0","1","undefined","π"],"correct":0, "why":"tan(0)=0/1=0"},
    {"rating":560,"q":"sin(90°) = ?","a":["0","1","√3/2","−1"],"correct":1, "why":"90° = π/2 rad ⇒ sin=1."},
    {"rating":580,"q":"cos(90°) = ?","a":["0","1","−1","0"],"correct":3, "why":"cos(90°)=0"},
    {"rating":600,"q":"tan(45°) = ?","a":["1","0","√3","1/√3"],"correct":0, "why":"45° triangle legs equal ⇒ tan=1."},
    {"rating":620,"q":"sin(30°) = ?","a":["1/2","√3/2","0","1"],"correct":0, "why":"30-60-90 triangle"},
    {"rating":640,"q":"cos(60°) = ?","a":["1/2","√3/2","0","1"],"correct":0, "why":"60° in unit circle"},
    {"rating":660,"q":"sin(π/6) = ?","a":["1/2","√3/2","0","1"],"correct":0, "why":"π/6=30°, sin=1/2."},
    {"rating":680,"q":"cos(π/3) = ?","a":["1/2","√3/2","0","1"],"correct":0, "why":"π/3=60°, cos=1/2."}
  ],
  calc1: [
    { rating: 560, q: "d/dx(x²) = ?", a: ["x", "2x", "x²", "2"], correct: 1, why: "Power rule" },
    { rating: 590, q: "∫ x dx = ?", a: ["x", "x²/2", "2x", "ln x"], correct: 1, why: "Antiderivative" },
    { rating: 620, q: "lim (x→1) (x²−1)/(x−1) = ?", a: ["0", "1", "2", "undefined"], correct: 2, why: "Factor" }
  ],
  code_puzzles: [
    { rating: 600, q: "Binary search time complexity?", a: ["O(n)","O(log n)","O(n²)","O(1)"], correct: 1, why: "Halves search" },
    { rating: 630, q: "A stack is…", a: ["FIFO","LIFO","Tree","Graph"], correct: 1, why: "Last-In First-Out" }
  ],
  chem1: [
    { rating: 550, q: "Water formula?", a: ["H2O","CO2","O2","H2"], correct: 0, why: "H2O" },
    { rating: 610, q: "Avogadro's number?", a: ["6.02×10²³","3.14","9.81","1.6×10⁻¹⁹"], correct: 0, why: "Particles per mole" }
  ]
};

// Elo utilities
const expected: ExpectedFn = (player, opp) => 1 / (1 + Math.pow(10, (opp - player) / 400));

const updateElo: UpdateEloFn = (player, qRating, correct, K = 24, min = 100) => {
  const E = expected(player, qRating);
  const S = correct ? 1 : 0;
  return Math.max(min, Math.round(player + K * (S - E)));
};

const updateLearnElo: UpdateLearnEloFn = (player, qRating, correct, min = 100) => {
  const E = expected(player, qRating);
  const S = correct ? 1 : 0;
  const K = correct ? 32 : 12;
  return Math.max(min, Math.round(player + K * (S - E)));
};

const pickQuestion: PickQuestionFn = (bank, playerElo, target = 100, step = 50, max = 300) => {
  const avail = bank.filter(q => !q._used);
  if (!avail.length) return null;

  let window = target;
  let candidates: Question[] = [];
  while (window <= max && candidates.length === 0) {
    candidates = avail.filter(q => Math.abs(q.rating - playerElo) <= window);
    if (!candidates.length) window += step;
  }
  if (!candidates.length) candidates = avail;
  const chosen = candidates[Math.floor(Math.random() * candidates.length)];
  chosen._used = true;
  return chosen;
};

export default function AdaptiveEloQuiz() {
  const [screen, setScreen] = useState<'home' | 'learn' | 'play' | 'profile'>('home');
  const [topicElos, setTopicElos] = useState<EloMap>({});
  const [learnElos, setLearnElos] = useState<EloMap>({});
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  
  const [learnActive, setLearnActive] = useState<boolean>(false);
  const [learnQ, setLearnQ] = useState<Question | null>(null);
  const [learnCount, setLearnCount] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const getTopicElo = (id: string): number => topicElos[id] || 600;
  const getLearnElo = (id: string): number => learnElos[id] || 600;
  
  const getOverallElo = () => {
    const allTopics = Object.values(SUBJECTS).flatMap(s => s.topics.map(t => t.id));
    const sum = allTopics.reduce((acc, id) => acc + getTopicElo(id), 0);
    return Math.round(sum / allTopics.length);
  };

  const startLearn = (topicId: string) => {
    const bank = QUESTION_BANK[topicId as string];
    if (!bank || bank.length === 0) {
      alert('No questions available for this topic');
      return;
    }

    bank.forEach(q => q._used = false);

    setSelectedTopic(topicId);
    setLearnActive(true);
    setLearnCount(0);
    const question = pickQuestion(bank, getLearnElo(topicId));
    setLearnQ(question);
    setSelectedAnswer(null);
    setShowFeedback(false);
  };

  const answerLearn = (idx: number) => {
    if (!learnQ || showFeedback) return;
    
    setSelectedAnswer(idx);
    setShowFeedback(true);
    
    const correct = idx === learnQ.correct;
  const currentLearnElo = getLearnElo(selectedTopic as string);
    
    // Update only the hidden learn Elo (used for question selection)
    const newLearnElo = updateLearnElo(currentLearnElo, learnQ.rating, correct);
  setLearnElos(prev => ({ ...prev, [selectedTopic as string]: newLearnElo }));
    
    // Visible Elo (multiplayer Elo) stays unchanged in Learn mode
    // It only updates during actual multiplayer matches
    
    setLearnCount(prev => prev + 1);

    setTimeout(() => {
      if (learnCount + 1 >= 5) {
        setLearnActive(false);
        setSelectedSubject(null);
        alert('Practice session complete! Keep learning to improve your rating.');
      } else {
  const bank = QUESTION_BANK[selectedTopic as string];
        setLearnQ(pickQuestion(bank, newLearnElo));
        setSelectedAnswer(null);
        setShowFeedback(false);
      }
    }, 2000);
  };

  const renderHome = () => (
    <div className="p-4 space-y-6">
      <div className="text-center mb-8">
        <div className="text-5xl font-bold text-blue-600 mb-2">{getOverallElo()}</div>
        <div className="text-gray-600">Overall Elo Rating</div>
      </div>

      <div className="grid gap-4">
        <button
          onClick={() => setScreen('learn')}
          className="bg-purple-600 text-white p-6 rounded-xl flex items-center justify-between hover:bg-purple-700 transition"
        >
          <div className="flex items-center gap-3">
            <Book className="w-8 h-8" />
            <div className="text-left">
              <div className="text-xl font-bold">Learn</div>
              <div className="text-sm opacity-90">Practice with adaptive questions</div>
            </div>
          </div>
        </button>

        <button
          onClick={() => setScreen('play')}
          className="bg-blue-600 text-white p-6 rounded-xl flex items-center justify-between hover:bg-blue-700 transition"
        >
          <div className="flex items-center gap-3">
            <Play className="w-8 h-8" />
            <div className="text-left">
              <div className="text-xl font-bold">Play</div>
              <div className="text-sm opacity-90">Online multiplayer</div>
            </div>
          </div>
          <Trophy className="w-6 h-6" />
        </button>
      </div>
    </div>
  );

  const renderLearn = () => (
    <div className="p-4">
      {!selectedSubject ? (
        <>
          <h2 className="text-2xl font-bold mb-4">Choose a Subject</h2>
          <div className="space-y-3">
            {Object.entries(SUBJECTS).map(([key, subject]) => (
              <button
                key={key}
                onClick={() => setSelectedSubject(key)}
                className="w-full bg-white border-2 border-gray-200 p-6 rounded-xl hover:border-purple-400 transition text-left"
              >
                <div className="font-bold text-xl mb-1">{subject.title}</div>
                <div className="text-sm text-gray-500">{subject.topics.length} topics</div>
              </button>
            ))}
          </div>
        </>
      ) : !learnActive ? (
        <>
          <button onClick={() => setSelectedSubject(null)} className="mb-4 text-purple-600 font-medium">
            ← Back to Subjects
          </button>
          <h2 className="text-2xl font-bold mb-4">{SUBJECTS[selectedSubject as string].title}</h2>
          <div className="space-y-3">
            {SUBJECTS[selectedSubject as string].topics.map((topic: { id: string; name: string }) => (
              <button
                key={topic.id}
                onClick={() => startLearn(topic.id)}
                className="w-full bg-white border-2 border-gray-200 p-4 rounded-xl hover:border-purple-400 transition text-left"
              >
                <div className="font-bold text-lg">{topic.name}</div>
                <div className="text-sm text-gray-500">
                  {QUESTION_BANK[topic.id]?.length || 0} questions • Practice 5 questions
                </div>
              </button>
            ))}
          </div>
        </>
      ) : (
        <div className="space-y-4">
          <div className="bg-white border-2 border-gray-200 rounded-xl p-4">
            <div className="flex justify-between items-center mb-4">
              <div className="text-sm text-gray-600">Progress: {learnCount + 1}/5</div>
              <div className="text-sm text-gray-600">Question: {learnQ!.rating} Elo</div>
            </div>
            <h3 className="text-xl font-bold mb-4">{learnQ!.q}</h3>
            <div className="space-y-3">
              {learnQ!.a.map((answer, idx) => {
                let bgColor = 'bg-gray-50 hover:bg-gray-100';
                if (showFeedback) {
                  if (idx === learnQ!.correct) {
                    bgColor = 'bg-green-100 border-green-500';
                  } else if (idx === selectedAnswer) {
                    bgColor = 'bg-red-100 border-red-500';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => answerLearn(idx)}
                    disabled={showFeedback}
                    className={`w-full p-4 rounded-xl border-2 transition ${bgColor} ${
                      showFeedback ? 'cursor-not-allowed' : 'border-gray-200'
                    }`}
                  >
                    <div className="font-medium text-left">{answer}</div>
                  </button>
                );
              })}
            </div>
          </div>
          
          {showFeedback && (
            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
              <div className="font-bold text-blue-900 mb-2">Explanation</div>
              <div className="text-sm text-blue-800">{learnQ!.why || "Review the concept"}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );

  const renderPlay = () => (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Play</h2>
      <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6 text-center">
        <Trophy className="w-16 h-16 mx-auto mb-4 text-blue-600" />
        <h3 className="text-xl font-bold text-blue-900 mb-2">Coming Soon!</h3>
        <p className="text-blue-800 mb-4">Online multiplayer matches are in development.</p>
        <div className="text-sm text-blue-700">
          Challenge other players in real-time 1v1 matches with Elo-based matchmaking.
        </div>
      </div>
    </div>
  );

  const renderProfile = () => {
    const allTopics = Object.values(SUBJECTS).flatMap(s => s.topics);
    
    return (
      <div className="p-4">
        <h2 className="text-2xl font-bold mb-4">Profile</h2>
        <div className="bg-white rounded-xl border-2 border-gray-200 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 text-center">
            <div className="text-5xl font-bold mb-2">{getOverallElo()}</div>
            <div className="text-sm opacity-90">Overall Elo Rating</div>
          </div>
          <div className="p-4">
            <h3 className="font-bold mb-3">Topic Ratings</h3>
            <div className="space-y-2">
              {allTopics.map(topic => (
                <div key={topic.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium">{topic.name}</span>
                  <span className="text-xl font-bold text-blue-600">{getTopicElo(topic.id)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-white border-b sticky top-0 z-30 shadow-sm">
        <div className="p-4">
          <h1 className="text-2xl font-bold text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Adaptive Elo Quiz
          </h1>
        </div>
      </header>

      <main className="pb-4">
        {screen === 'home' && renderHome()}
        {screen === 'learn' && renderLearn()}
        {screen === 'play' && renderPlay()}
        {screen === 'profile' && renderProfile()}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-20">
        <div className="flex justify-around p-2">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'learn', icon: Book, label: 'Learn' },
            { id: 'play', icon: Play, label: 'Play' },
            { id: 'profile', icon: User, label: 'Profile' }
          ].map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => {
                setScreen(id as 'home' | 'learn' | 'play' | 'profile');
                setSelectedSubject(null);
                setLearnActive(false);
              }}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition ${
                screen === id ? 'text-blue-600 bg-blue-50' : 'text-gray-600'
              }`}
            >
              <Icon className="w-6 h-6" />
              <span className="text-xs font-medium">{label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}