export interface Question {
  rating: number;
  q: string;
  a: string[];
  correct: number;
  why: string;
  _used?: boolean;
}

export interface Topic {
  id: string;
  name: string;
}

export interface Subject {
  title: string;
  topics: Topic[];
}

export interface Subjects {
  [key: string]: Subject;
}

export interface QuestionBank {
  [key: string]: Question[];
}

export interface EloMap {
  [key: string]: number;
}