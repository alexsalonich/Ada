declare interface Question {
  rating: number;
  q: string;
  a: string[];
  correct: number;
  why: string;
  _used?: boolean;
}

declare interface Topic {
  id: string;
  name: string;
}

declare interface Subject {
  title: string;
  topics: Topic[];
}

declare interface Subjects {
  [key: string]: Subject;
}

declare interface QuestionBank {
  [key: string]: Question[];
}

declare interface EloMap {
  [key: string]: number;
}

// Utility function types
declare type ExpectedFn = (player: number, opp: number) => number;
declare type UpdateEloFn = (player: number, qRating: number, correct: boolean, K?: number, min?: number) => number;
declare type UpdateLearnEloFn = (player: number, qRating: number, correct: boolean, min?: number) => number;
declare type PickQuestionFn = (bank: Question[], playerElo: number, target?: number, step?: number, max?: number) => Question | null;