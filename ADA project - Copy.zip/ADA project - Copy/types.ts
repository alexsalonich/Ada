interface Question {
  rating: number;
  q: string;
  a: string[];
  correct: number;
  why: string;
  _used?: boolean;
}

interface Topic {
  id: string;
  name: string;
}

interface Subject {
  title: string;
  topics: Topic[];
}

interface Subjects {
  [key: string]: Subject;
}

interface QuestionBank {
  [key: string]: Question[];
}

interface EloMap {
  [key: string]: number;
}

// Utility function types
type ExpectedFn = (player: number, opp: number) => number;
type UpdateEloFn = (player: number, qRating: number, correct: boolean, K?: number, min?: number) => number;
type UpdateLearnEloFn = (player: number, qRating: number, correct: boolean, min?: number) => number;
type PickQuestionFn = (bank: Question[], playerElo: number, target?: number, step?: number, max?: number) => Question | null;

export type {
  Question,
  Topic,
  Subject,
  Subjects,
  QuestionBank,
  EloMap,
  ExpectedFn,
  UpdateEloFn,
  UpdateLearnEloFn,
  PickQuestionFn
};